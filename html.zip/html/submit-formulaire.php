<?php

$options = array('options' => array('min_range' => 1,'max_range' => 10));

if (
    (!isset($_POST['prenom']) || empty($_POST['prenom']))
    || (!isset($_POST['nom']) || empty($_POST['nom']))
    || (!isset($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
    || (!isset($_POST['note']) || !filter_var($_POST['note'], FILTER_VALIDATE_INT, $options))
    || (!isset($_POST['date']) || !checkdate(substr($_POST['date'],5,2),substr($_POST['date'],8,2),substr($_POST['date'],0,4)))
    )
{
	echo('Formulaire invalide ! Veuillez recommencer !');
	return;
}

$prenom = htmlspecialchars($_POST['prenom']);
$nom = htmlspecialchars($_POST['nom']);
$email = htmlspecialchars($_POST['email']);
$avis = htmlspecialchars($_POST['avis']);

try
{
	$db = new PDO('mysql:host=localhost;dbname=Avis;charset=utf8', 'root', '');
}
catch (Exception $e)
{
	die('Erreur : ' . $e->getMessage());
}

$sqlQuery = 'INSERT INTO Avis(prenom, nom, email, note, avis, date) VALUES (:prenom, :nom, :email, :note, :avis, :date)';

$insertAvis = $db->prepare($sqlQuery);

$insertAvis->execute([
    'prenom' => $prenom,
    'nom' => $nom,
    'email' => $email,
    'note' => $_POST[ 'note'],
    'avis' => $avis,
    'date' => $_POST[ 'date'],
]);

?>

<!DOCTYPE html>
<!-- Message de réception de l'avis -->
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="auteur" content="Georges Miot">
  <meta name="description" content="Message de réception du formulaire">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="styles/style.css">
  <title>Réception</title>
</head>
<body>
  <h1 style="text-align:center">Avis bien reçu <?php echo $prenom; ?> !</h1>
  <h3>Rappel de vos informations</h3>
  <div style="border: solid">
    <p>
      <strong>Prénom</strong>: <?php echo $prenom; ?>
    </p>
    <p>
      <strong>Nom</strong>: <?php echo $nom; ?>
    </p>
    <p>
      <strong>Email</strong>: <?php echo $email; ?>
    </p>
  </div>
  <h3>Votre note et avis</h3>
  <div style="border: solid">
    <p>
      <strong>Note</strong>: <?php echo $_POST[ 'note']; ?>
    </p>
    <p>
      <strong>Avis</strong>: <?php echo $avis; ?>
    </p>
  </div>
  <footer>
    <p>
      <form action="avis.php" method="get" style="text-align:center">
        <button type="submit">Voir les avis</button>
      </form>
      <br>
      <form style="text-align:center">
        <input type="button" value="Fermer" onclick="parent.close();">
      </form>
    </p>
  </footer>
</body>
</html>
