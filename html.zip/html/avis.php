<?php
try
{
	$db = new PDO('mysql:host=localhost;dbname=Avis;charset=utf8', 'root', '');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}


$sqlQuery = 'SELECT *, DATE_FORMAT(date, "%d/%c/%Y") AS date FROM Avis';
$AvisStatement = $db->prepare($sqlQuery);
$AvisStatement->execute();
$Avis = $AvisStatement->fetchAll();

?>

<!DOCTYPE html>
<!-- Page des Avis -->
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="auteur" content="Georges Miot">
  <meta name="description" content="Page des avis du site">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="styles/style.css">
  <title>Avis</title>
</head>

<body>
  <header>
    <h1 style="text-align:center">Avis</h1>
  </header>
  <nav>
    <a href="index.html">INDEX</a>
    <a href="cv-html.html">HTML</a>
    <a href="cv-html-css-php-mysql.html">HTML+CSS</a>
    <a href="cv-html-css-php-mysql-js.html">HTML+CSS+JS</a>
    <a href="avis.php">AVIS</a>
  </nav>
  <br>
  <br>
  <form action="formulaire.php" method="get" target="_blank" style="text-align:center">
  	<button type="submit">Donnez votre avis !</button>
  </form>
<?php
foreach ($Avis as $Avi) {
?><br>
	<div style= "border: solid">
    <p><strong>Date: </strong><?php echo $Avi['date']; ?></p>
    <p><strong>Prénom: </strong><?php echo $Avi['prenom']; ?></p>
    <p><strong>Nom: </strong><?php echo $Avi['nom']; ?></p>
    <p><strong>Email: </strong><?php echo $Avi['email']; ?></p>
    <p><strong>Note: </strong><?php echo $Avi['note']; ?></p>
    <p><strong>Avis: </strong><?php echo $Avi['avis']; ?></p>
	</div>
<?php
}
?>
  <br>
  <footer style="background:#303030;border:solid;">
  	<form action="formulaire.php" method="get" target="_blank" style="text-align:center">
	   	<button type="submit">Donnez votre avis !</button>
	  </form>
  </footer>
</body>

</html>
