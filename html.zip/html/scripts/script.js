let couleur = 'clair'
let elt = document.getElementById('myonoffswitch');
let titre = document.getElementById('titre');

elt.addEventListener('click', function() {

if (couleur == 'clair') {

document.body.style.backgroundColor = 'black';
titre.style.backgroundColor = '#2F4F4F';
document.body.style.color = '#F5F5F5';
couleur = 'sombre';

} else {

document.body.style.backgroundColor = '#FDF1B8';
titre.style.backgroundColor = '#C8AD7F';
document.body.style.color = 'black';
couleur = 'clair';
}

});
