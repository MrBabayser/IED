<!DOCTYPE html>
<!-- formulaire pour noter et donner son avis sur le site -->
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="auteur" content="Georges Miot">
  <meta name="description" content="Formulaire">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="styles/style.css">
  <title>Formulaire</title>
</head>

<body>
  <header>
    <h1 style="text-align:center">Formulaire</h1>
  </header>
  <form method="post" action="submit-formulaire.php">
    <p>
      <fieldset>
        <legend>Vos coordonnées</legend>
        <label for="prénom">Votre prénom :</label>
        <input type="text" name="prenom" id="prenom" placeholder="Ex : Georges" size="30" maxlength="20" required/>
        <br>
        <br>
        <label for="nom">Votre nom :</label>
        <input type="text" name="nom" id="nom" placeholder="Ex : Miot" size="30" maxlength="20" required/>
        <br>
        <br>
        <label for="email">Votre e-mail :</label>
        <input type="email" name="email" id="email" placeholder="Ex : miot.georges@gmail.com" size="30" required/>
      </fieldset>
      <br>
      <fieldset>
        <legend>Votre avis</legend>
        <label for="note">Votre note du site sur une échelle de 1 à 10 :</label>
        <input type="number" name="note" id="note" min=0 max=10 required/>
        <br>
        <br>
        <label for="avis">Quel est votre avis sur le site ?</label>
        <br>
        <textarea name="avis" id="avis" rows="10" cols="135">Sympa le site !</textarea>
      </fieldset>
    </p>
    <footer style="background:#303030;border:solid;text-align:center;color:white">
      <p>
        <label for="date">Date de l'avis :</label>
        <input type="date" name="date" id="date" required/>
        <br>
        <br>
        <input type="reset" value="Effacer tout" />
        <input type="submit" value="Envoyer" />
        <input type="button" value="Fermer" onclick="window.close();">
      </p>
    </footer>
  </form>
</body>

</html>
